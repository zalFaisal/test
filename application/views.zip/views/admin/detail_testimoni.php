<link href="<?php echo base_url('assets');?>/ace/assets/css/bootstrap.min.css" rel="stylesheet" />
		<link href="<?php echo base_url('assets');?>/ace/assets/css/bootstrap-responsive.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/font-awesome.min.css" />
		<script src="<?php echo base_url('assets');?>/Js/jquery.min.js"></script>

		<!--[if IE 7]>
		  <link rel="stylesheet" href="ace/assets/css/font-awesome-ie7.min.css" />
		<![endif]-->

		<!--page specific plugin styles-->

		<!--fonts-->

		<!-- <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" /> -->

		<!--ace styles-->

		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace.min.css" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace-responsive.min.css" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace-skins.min.css" />
		<script  type="text/javascript" src="<?php echo base_url('assets');?>/ckeditor/ckeditor.js"></script>
<form action="<?php echo site_url('Admin/ubahTestimoni'); ?>" method="post"  enctype="multipart/form-data">
					<?php foreach($product as $produk):?>
					<input type="hidden" name="id_produk" value="<?= $produk['id_testimoni']; ?>">
				
					<div class="form-group">
						<label>Nama Lengkap</label>
						<input name="nama_produk" type="text" class="form-control" placeholder="Nama Lengkap .." value="<?= $produk['nama_lengkap']; ?>"  required="required">
					</div>
					<div class="form-group">
						<label>E-mail</label>
						<input name="email" type="email" class="form-control" placeholder="sample@gmail.com"  required="required" pattern="*@*.*" value="<?= $produk['email']; ?>">
					</div>
					<div class="form-group">
						<label>Testimoni</label>
						<textarea name="deskripsi" class="ckeditor1" id="ckeditor1" placeholder="Deskripsi ..">
							<?= $produk['testimoni']; ?>
						</textarea>
					</div>
					
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
					<input type="submit" class="btn btn-primary" value="Simpan">
				</div>
			<?php endforeach;?>
			</form>
			<script>
	ClassicEditor
		.create( document.querySelector( '#ckeditor1' ), {
			// toolbar: [ 'heading', '|', 'bold', 'italic', 'link' ]
		} )
		.then( editor => {
			window.editor = editor;
		} )
		.catch( err => {
			console.error( err.stack );
		} );
</script>