<link href="<?php echo base_url('assets');?>/ace/assets/css/bootstrap.min.css" rel="stylesheet" />
		<link href="<?php echo base_url('assets');?>/ace/assets/css/bootstrap-responsive.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/font-awesome.min.css" />
		<script src="<?php echo base_url('assets');?>/Js/jquery.min.js"></script>

		<!--[if IE 7]>
		  <link rel="stylesheet" href="ace/assets/css/font-awesome-ie7.min.css" />
		<![endif]-->

		<!--page specific plugin styles-->

		<!--fonts-->

		<!-- <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" /> -->

		<!--ace styles-->

		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace.min.css" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace-responsive.min.css" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace-skins.min.css" />
		
<form action="<?php echo site_url('Admin/ubahSubProduk'); ?>" method="post"  enctype="multipart/form-data">
	<?php foreach ($product as $product)?>
					<div class="form-group">
						<label>Nama Sub Produk</label>
						<input name="id_produk" type="hidden" value="<?php echo $product['id_sub_product'] ?>">
						<input name="nama_produk" type="text" class="form-control" placeholder="Nama Sub Produk .." value="<?php echo $product['sub_product_name'] ?>"  required="required">
					</div>
					<div class="form-group">
						<label>Nama Produk</label>
						<select name="kategory" class="form-control" required="required">
							<?php foreach ($kategory2 as $kategory2):?>
								<option value="<?php echo $kategory2['id_product'];?>"><?php echo $kategory2['product_name'];?></option>
							<?php foreach ($kategory as $kategory):?>
								<option value="<?php echo $kategory['id_product'];?>"><?php echo $kategory['product_name'];?></option>
							<?php endforeach;?>
						</select>
					</div>
					<div class="form-group">
						<label>Deskripsi Produk</label>
						<textarea name="deskripsi" type="text" class="form-control" placeholder="Deskripsi .." value="<?php echo $product['sub_description'] ?>"  required="required"><?php echo $product['sub_description'] ?></textarea>
					</div>
					<div class="form-group">
						<label>Harga</label>
						<input name="harga_produk" type="text" class="form-control" placeholder="Harga Produk .." value="<?php echo $product['price'] ?>"  required="required">
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
					<input type="submit" class="btn btn-primary" value="Simpan">
				</div>
			<?php endforeach;?>
			</form>