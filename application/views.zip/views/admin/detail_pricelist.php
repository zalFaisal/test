<link href="<?php echo base_url('assets');?>/ace/assets/css/bootstrap.min.css" rel="stylesheet" />
		<link href="<?php echo base_url('assets');?>/ace/assets/css/bootstrap-responsive.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/font-awesome.min.css" />
		<script src="<?php echo base_url('assets');?>/Js/jquery.min.js"></script>

		<!--[if IE 7]>
		  <link rel="stylesheet" href="ace/assets/css/font-awesome-ie7.min.css" />
		<![endif]-->

		<!--page specific plugin styles-->

		<!--fonts-->

		<!-- <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" /> -->

		<!--ace styles-->

		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace.min.css" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace-responsive.min.css" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace-skins.min.css" />
		
<form action="<?php echo site_url('Admin/ubahPricelist'); ?>" method="post"  enctype="multipart/form-data">
	<?php foreach ($product as $product):?>
					<div class="form-group">
						<label>Quantity</label>
						<input name="id_produk" type="hidden" value="<?php echo $product['id_pricelist'] ?>">
						<input name="quantity" type="number" class="form-control" placeholder="Quantity..." value="<?php echo $product['quantity'] ?>"  required="required">
					</div>
					<div class="form-group">
						<label>Satuan</label>
						<select name="satuan" class="form-control"  required="required">
							<?php if($product['satuan']=='PCS'){?>
							<option value="PCS">PCS</option>
							<option value="BOX">BOX</option>
							<option value="DUS">DUS</option>
							<option value="PACK">PACK</option>
							<option value="RIM">RIM</option>
							<?php }?>
							<?php if($product['satuan']=='BOX'){?>
							<option value="BOX">BOX</option>
							<option value="PCS">PCS</option>
							<option value="DUS">DUS</option>
							<option value="PACK">PACK</option>
							<option value="RIM">RIM</option>
							<?php }?>
							<?php if($product['satuan']=='DUS'){?>
							<option value="DUS">DUS</option>
							<option value="BOX">BOX</option>
							<option value="PCS">PCS</option>
							<option value="PACK">PACK</option>
							<option value="RIM">RIM</option>
							<?php }?>
							<?php if($product['satuan']=='PACK'){?>
							<option value="PACK">PACK</option>
							<option value="BOX">BOX</option>
							<option value="DUS">DUS</option>
							<option value="PCS">PCS</option>
							<option value="RIM">RIM</option>
							<?php }?>
							<?php if($product['satuan']=='RIM'){?>
							<option value="RIM">RIM</option>
							<option value="BOX">BOX</option>
							<option value="DUS">DUS</option>
							<option value="PACK">PACK</option>
							<option value="PCS">PCS</option>
							<?php }?>
						</select>
					<div class="form-group">
						<label>Harga Per Pcs</label>
						<input name="harga" type="number" class="form-control" placeholder="Exp: 1000" value="<?php echo $product['harga_per_pcs'] ?>"  required="required">
					</div>
					<div class="form-group">
						<label>Nama Produk</label>
						<select name="produk" class="form-control"  required="required">
							<?php foreach ($kategory2 as $kategory2)?>
								<option value="<?php echo $kategory2['id_product'];?>"><?php echo $kategory2['product_name'];?></option>
							<?php foreach ($kategory as $kategory):?>
								<option value="<?php echo $kategory['id_product'];?>"><?php echo $kategory['product_name'];?></option>
							<?php endforeach;?>
						</select>
					</div>
					<div class="form-group">
						<label>Nama Bahan</label>
						<select name="bahan" class="form-control"  required="required">
							<?php foreach ($bahan2 as $bahan2)?>
								<option value="<?php echo $bahan2['id_bahan'];?>"><?php echo $bahan2['nama_bahan'];?></option>
							<?php foreach ($bahan as $bahan):?>
								<option value="<?php echo $bahan['id_bahan'];?>"><?php echo $bahan['nama_bahan'];?></option>
							<?php endforeach;?>
						</select>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
					<input type="submit" class="btn btn-primary" value="Simpan">
				</div>
			<?php endforeach;?>
			</form>