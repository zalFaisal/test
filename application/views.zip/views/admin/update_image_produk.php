<link href="<?php echo base_url('assets');?>/ace/assets/css/bootstrap.min.css" rel="stylesheet" />
		<link href="<?php echo base_url('assets');?>/ace/assets/css/bootstrap-responsive.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/font-awesome.min.css" />
		<script src="<?php echo base_url('assets');?>/Js/jquery.min.js"></script>

		<!--[if IE 7]>
		  <link rel="stylesheet" href="ace/assets/css/font-awesome-ie7.min.css" />
		<![endif]-->

		<!--page specific plugin styles-->

		<!--fonts-->

		<!-- <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" /> -->

		<!--ace styles-->

		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace.min.css" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace-responsive.min.css" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace-skins.min.css" />
		
<form action="<?php echo site_url('Admin/ubahFotoProduk'); ?>" method="post"  enctype="multipart/form-data">
	<?php foreach ($product as $product):?>
					<div class="form-group">
						<label>Nama Produk</label>
						<input name="id_produk" type="hidden" value="<?php echo $product['id_product'] ?>">
						<input name="nama_produk" type="text" class="form-control" placeholder="Nama Produk .." value="<?php echo $product['product_name'] ?>" disabled>
					</div>
					<div class="form-group">
						<label>Foto Banner Promosi</label>
						<input name="foto_banner" type="file" class="form-control" placeholder="Foto Banner .." required="required">
					</div>
					<div class="form-group">
						<label>Foto Thumbnail</label>
						<input name="foto_thumbnail" type="file" class="form-control" placeholder="Foto Thumbnail .." required="required">
					</div>
					<div class="form-group">
						<label><i><strong>*Catatan : Jika anda merubah foto, maka anda harus merubah keduanya.</strong></i></label>
					</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
					<input type="submit" class="btn btn-primary" value="Simpan">
				</div>
			<?php endforeach;?>
			</form>