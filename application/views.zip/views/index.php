<?php $posisi = ""; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Rony Design - Percetakan</title>
    <link rel="icon" href="<?php echo base_url()?>assets/images/icon.jpg">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/font-awesome.min.css">
    
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/jquery-ui.css">

  <link href="https://fonts.googleapis.com/css?family=Bitter|Mukta|Oswald|Roboto+Condensed|Staatliches" rel="stylesheet"> 
  <link type="text/css" rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css?<?php echo time();?>">
  <!-- nouislider -->
  <!-- Font Awesome Icon -->
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/font-awesome.min.css">
   
  
  </head>
  <style type="text/css">
  @media only screen and (max-width: 740px){
    .card-testimoni{
  height: auto;
  width: 260px;
  background: #fff;
  border: #d1d8e0 1px solid;
  color: #f7b731;
  padding: 10px;
  border-radius: 2px;
  margin-right: auto;
  margin-left: auto;
  text-align: center;
  transition: all 0.3s ease 0s;
  font-size: 14px;
  display: inline-block;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -ms-box-sizing: border-box;
  -o-box-sizing: border-box;
}
.card-testimoni:hover{
  box-shadow: 0px 10px 15px rgba(0, 0, 0, 0.1);
}
    .foto-ban{
      min-width: 100%;
      min-height: 200px;
      max-height: 200px;
      max-width: 100%;
    }
   .col-deskripsi{
  width: 90%;
  height: auto;
  position: relative;
  padding-left: 15px;
  }
  .head-des{
    padding-left: 15px;
  }
  .foto-banner{
    width: 100%;
    height: 225px;
  }
  }
  @media only screen and (min-width: 768px){
    .card-testimoni{
  position: none;
float: left;
  height: auto;
  width: 260px;
  background: #fff;
  border: #d1d8e0 1px solid;
  color: #f7b731;
  padding: 10px;
  border-radius: 2px;
  margin-right: auto;
  margin-left: auto;
  text-align: center;
  transition: all 0.3s ease 0s;
  font-size: 14px;
  display: inline-block;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -ms-box-sizing: border-box;
  -o-box-sizing: border-box;
}
.card-testimoni:hover{
  box-shadow: 0px 10px 15px rgba(0, 0, 0, 0.1);
}
    .foto-ban{
      padding-top: 0px;
      min-width: 100%;
      min-height: 530px;
      max-height: 530px;
      max-width: 100%;
    }
  .col-deskripsi{
  width: 55%;
  height: auto;
  position: relative;
  padding-left: 149px;
}
.head-des{
    padding-left: 149px;
  }
  .foto-banner{
    width: 98%;
    height: 580px;
  }
  }
  
  .foto{
    width: 50px;
    height: 180px;
  }
  .jarak-kiri{
    padding-left: 10px;
  }

  </style>
  <body>
  
  <div class="site-wrap">
    <header class="site-navbar" role="banner">
      <div id="top-header" style="background: #cccccc;">
      <div class="container">
        <div class="pull-right">
            <a href="https://api.whatsapp.com/send?phone=6281322220417&text=Hallo%20RonysDesign.com" target="_blank" style="color: #636e72;font-family: 'Roboto Condensed', sans-serif;"><i class="fa fa-whatsapp"></i><span> 081322220417 | </span></a>
            <a href="mailto:ronysdesign@gmail.com" style="color: #636e72;font-family: 'Roboto Condensed', sans-serif;"><i class="fa fa-envelope"></i>  <span>ronysdesign@gmail.com</span></a>
        </div>
      </div>
    </div>
      <div class="site-navbar-top">
        <div class="container">
          <div class="row align-items-center">

            <div class="col-6 mb-3 mb-md-0 col-md-4 order-1 order-md-2 text-left logo-position">
              <div class="site-logo">
               <img src="<?php echo base_url().'assets/images/riffData.png'?>" class="logo" onclick="location.href='<?php echo site_url('')?>'">
              </div>
            </div>

            <div class="col-6 col-md-4 order-2 order-md-1 site-search-icon text-right logo-position-sc">
              <div class="header-search">
            <form action="<?php echo site_url('search');?>" method="get">
              <input class="input search-input" name="q" type="text" placeholder="Cari Produk">
              <button class="search-btn"><i class="fa fa-search" style="color: #fff;"></i></button>
            </form>
          </div>
            </div>

            
            <div id="header">
            <div class="col-12 mb-3 mb-md-0 col-md-4 order-1 order-md-2 text-left">
              <br><br>
             <span class="nav-toggle">
              <button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
            </span>
            </div>
            </div>
          </div>
        </div>
      </div> 
      <div id="navigation">
    <!-- container -->
    <div class="container">
      <div id="responsive-nav">

        <!-- menu nav -->
        <div class="menu-nav">
          <span class="menu-header">Menu <i class="fa fa-bars"></i></span>
          <ul class="menu-list">
            <?php foreach ($kategory as $kategory):
              $this->load->model('Transaksi');
              $id_kat = $kategory['id_kategory'];
              $produk = $this->Transaksi->getProduk($id_kat);
              ?>
            <li class="dropdown mega-dropdown full-width"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" style="cursor: default;"><?php echo $kategory['nama_kategory'] ?><i class="fa fa-caret-down jarak-kiri"></i></a>
              <div class="custom-menu">
                <div class="row">
                  <?php foreach ($produk as $produk):?>
                  <div class="col-md-2">
                    <div class="hidden-sm hidden-xs">
                      <a href="<?php echo site_url('product/'.$produk['slug_name']);?>">
                        <img style="width: 170px;height: 170px;" src="<?php echo base_url().'uploads/'.$produk['product_photo']?>" alt=""></a>
                    </div>
                    <a href="<?php echo site_url('product/'.$produk['slug_name']);?>">
                    <div class="text-left">
                       <h5 class="text-uppercase"><p><?php echo $produk['product_name'];?></p></h5>
                    </div>
                  </a>
                  </div>
                <?php endforeach;?>
                </div>
              </div>
            </li>
          <?php endforeach;?>
            <li><a href="<?php echo site_url('blog');?>" style="cursor: default;">BLOG</a></li>
          </ul>
        </div>
        <!-- menu nav -->
      </div>
    </div>
    <!-- /container -->
  </div>
    </header>
      
  
  <div id="myCarousel" class="carousel slide" data-ride="carousel" style="width: 100%;">
    <!-- Indicators -->
    

    <!-- Wrapper for slides -->
    <div class="carousel-inner" style="width: 100%;">
      <?php 
      $n=1;
      $brs = 0;
      $act = "";
      $bar =[];
      foreach($promosi as $promo):
        $bar[$brs]=$brs;
        if($n==1){
          $act="active";
        }else{
          $act="";
        }
        ?>
      <div class="item <?= $act?>" style="width: 100%;">
        <a href="<?php echo site_url('promotion/'.$promo['slug_name_promosi'])?>" target="_blank"><img src="<?php echo base_url().'uploads/'.$promo['foto_banner_promosi']?>" alt="" class="foto-ban" ></a>
      </div>
    <?php 
    $n+=1;
    $brs+=1;
  endforeach;?>
    </div>
<ol class="carousel-indicators">
      <?php 
      $num =0;
      $aksi = "";
      while ($num < count($bar)){
        if($num==0){
          $aksi="active";
        }else{
          $aksi="";
        }
       ?>
      <li data-target="#myCarousel" data-slide-to="<?= $num;?>" class="<?= $aksi;?>"></li>
    <?php 
      $num+=1;
      } ?>
    </ol>
</div>


    <div class="site-section site-section-sm site-blocks-1">
      <div class="container">
        <div class="row">
          <hr width="98%" style="float: center;" align="center"><br><br>
        <?php foreach($video as $vid):
          $link_video =  $vid['link_url'];
          list($uri_seg1,$uri_seg2)=explode('=', $link_video);
        endforeach;
          ?>
        <iframe class="foto-banner" src="https://www.youtube.com/embed/<?php echo $uri_seg2;?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
      </div>
    </div>


    <div class="site-section site-section-sm site-blocks-1">
      <div class="container">
        <div class="row">
          
          <hr width="98%" style="float: center;" align="center"><center>
          <h3 class="text-center"  style="font-family: 'Oswald', sans-serif;text-align: center;">PRODUK PERCETAKAN</h3></center><br><br>
          <div class="isi">
          <?php foreach ($produklim as $produklim): ?>
           <!-- Product Single -->
            <span class="span-card">
              <center>
    <form class="card-produk">
      <img style="width: 240px;height: 180px;" src="<?php echo base_url().'uploads/'.$produklim['product_photo']?>" alt="">
        <br><br>
          <a href="<?php echo site_url('product/'.$produklim['slug_name']);?>">
          <p class="text-uppercase text-left" style="color: #576574;font-family: 'Bitter', serif;"><?php echo $produklim['product_name'];?></p>
          <hr width="100%">
          <p class="text-left"><i  style="color: #576574;font-family: 'Bitter', serif;"><?php echo substr($produklim['description'],0,40)?></i></p>
        </a>
    </form>
  </center>
  </span>
          <?php endforeach;?>
          <br>
          <center>
          <div style="padding-top: 50px;"><center><a href="<?php echo site_url('allproduct');?>"><button class="btn-all-produk">LIHAT SEMUA PRODUK</button></a></center></div></center>
        </div>
      
        </div>
      </div>
    </div>



      <div class="container">
        <div class="row">
          <hr width="98%" style="float: center;" align="center"><center>
          <h3 class="text-center"  style="font-family: 'Oswald', sans-serif;text-align: center;">TESTIMONI</h3></center><br><br>
          <div id="testimoni" class="carousel slide" data-ride="carousel">
    

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <?php
      foreach($testimoni as $testimoni):?>
        <span class="span-card-test">
          <center>
    <form class="card-testimoni">
      <img style="width: 120px;height: 120px; border-radius: 120px;" src="<?php echo base_url().'uploads/'.$testimoni['foto_testimoni']?>" alt=""><br>
      <span class="text-center" style="font-family: 'Bitter', serif; color: #f7b731;">
        <br>
          <p class="text-uppercase text-center" style="color: #576574;"><?php echo $testimoni['nama_lengkap'];?></p>
          <hr width="100%">
          <i class="text-center" style="color: #576574; font-size: 12px;">"<?php echo $testimoni['testimoni'];?>"</i>
      </span>
    </form>
  </center>
  </span>
  <?php  endforeach;?>
      </div>
      <div class="item">
        <?php
      foreach($testimoni2 as $testimoni2):?>
        <span class="span-card-test">
          <center>
    <form class="card-testimoni">
      <img style="width: 120px;height: 120px; border-radius: 120px;" src="<?php echo base_url().'uploads/'.$testimoni2['foto_testimoni']?>" alt=""><br>
      <span class="text-center" style="font-family: 'Bitter', serif; color: #f7b731;">
        <br>
          <p class="text-uppercase text-center" style="color: #576574;"><?php echo $testimoni2['nama_lengkap'];?></p>
          <hr width="100%">
          <i class="text-center" style="color: #576574; font-size: 12px;">"<?php echo $testimoni2['testimoni']?>"</i>
      </span>
    </form>
  </center>
  </span>
  <?php  endforeach;?>
      </div>
      <div class="item">
        <?php
      foreach($testimoni3 as $testimoni3):?>
        <span class="span-card-test">
          <center>
    <form class="card-testimoni">
      <img style="width: 120px;height: 120px; border-radius: 120px;" src="<?php echo base_url().'uploads/'.$testimoni3['foto_testimoni']?>" alt=""><br>
      <span class="text-center" style="font-family: 'Bitter', serif; color: #f7b731;">
        <br>
          <p class="text-uppercase text-center" style="color: #576574;"><?php echo $testimoni3['nama_lengkap'];?></p>
          <hr width="100%">
          <i class="text-center" style="color: #576574; font-size: 12px;">"<?php echo $testimoni3['testimoni']?>"</i>
      </span>
    </form>
  </center>
  </span>
  <?php  endforeach;?>
      </div>
    
    </div>

<!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#testimoni" data-slide-to="0" class="active" style="border: #8395a7 1px solid;"></li>
      <li data-target="#testimoni" data-slide-to="1" style="border: #8395a7 1px solid;"></li>
      <li data-target="#testimoni" data-slide-to="2" style="border: #8395a7 1px solid;"></li>
    </ol>
  </div>
            


        </div>
      </div>


      <div class="container">
          <hr width="98%" style="float: center;" align="center"><center>
          <h3 class="text-center"  style="font-family: 'Oswald', sans-serif;text-align: center;">PELANGGAN KAMI</h3></center><br><br>
          <div id="pelanggan" class="carousel slide" data-ride="carousel">
    

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <?php
      foreach($pelanggan as $pelanggan):?>
        <span class="span-pel">
          <center>
    <form class="card-testimoni">
           <img style="width: 130px;height: 120px" src="<?php echo base_url().'uploads/'.$pelanggan['foto_pelanggan']?>" alt="">
         </form>
       </center>
        </span>
  <?php  endforeach;?>
      </div>
      <div class="item">
        <?php
      foreach($pelanggan2 as $pelanggan2):?>
        <span class="span-pel">
          <center>
    <form class="card-testimoni">
           <img style="width: 130px;height: 120px" src="<?php echo base_url().'uploads/'.$pelanggan2['foto_pelanggan']?>" alt="">
       </form>
       </center>
        </span>
  <?php  endforeach;?>
      </div>
      <div class="item">
        <?php
      foreach($pelanggan3 as $pelanggan3):?>
        <span class="span-pel">
          <center>
    <form class="card-testimoni">
           <img style="width: 130px;height: 120px" src="<?php echo base_url().'uploads/'.$pelanggan3['foto_pelanggan']?>" alt="">
        </form>
       </center>
        </span>
  <?php  endforeach;?>
      </div>
    
    </div>

<!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#pelanggan" data-slide-to="0" class="active" style="border: #8395a7 1px solid;"></li>
      <li data-target="#pelanggan" data-slide-to="1" style="border: #8395a7 1px solid;"></li>
      <li data-target="#pelanggan" data-slide-to="2" style="border: #8395a7 1px solid;"></li>
    </ol>
  </div>
        
      </div>
    <div class="site-section site-section-sm site-blocks-1">
      <div class="container">
        <div class="row">
          <hr width="98%" style="float: center;" align="center">
          <h3 class="text-left"  style="font-family: 'Oswald', sans-serif;">BLOG</h3><br><br>
          <div id="blog" class="carousel slide" data-ride="carousel">
    

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <?php
      foreach($blog as $blog):?>
        <span class="span-card">
    <form class="card-blog">
      <img style="width: 240px;height: 180px;" src="<?php echo base_url().'uploads/'.$blog['img_blog']?>" alt="">
        <br><br>
          <a href="<?php echo site_url('archives/'.$blog['slug_name_blog']);?>">
          <p class="text-uppercase text-left" style="color: #576574;font-family: 'Bitter', serif;"><?php echo $blog['judul_blog'];?></p>
          <hr width="100%">
          <p class="text-left" style="color: #576574;font-family: 'Bitter', serif;"><?php echo substr($blog['konten'],0,50)?>...</p>
        </a>
    </form>
  </span>
  <?php  endforeach;?>
      </div>
      <div class="item">
        <?php
      foreach($blog2 as $blog2):?>
        <span class="span-card">
    <form class="card-blog">
      <img style="width: 240px;height: 180px;" src="<?php echo base_url().'uploads/'.$blog2['img_blog']?>" alt="">
        <br><br>
          <a href="<?php echo site_url('archives/'.$blog2['slug_name_blog']);?>">
          <p class="text-uppercase text-left" style="color: #576574;font-family: 'Bitter', serif;"><?php echo $blog2['judul_blog'];?></p>
          <hr width="100%">
          <p class="text-left" style="color: #576574;font-family: 'Bitter', serif;"><?php echo substr($blog2['konten'],0,50)?>...</p>
        </a>
    </form>
  </span>
  <?php  endforeach;?>
      </div>
      <div class="item">
        <?php
      foreach($blog3 as $blog3):?>
        <span class="span-card">
    <form class="card-blog">
      <img style="width: 240px;height: 180px;" src="<?php echo base_url().'uploads/'.$blog3['img_blog']?>" alt="">
        <br><br>
          <a href="<?php echo site_url('archives/'.$blog3['slug_name_blog']);?>">
          <p class="text-uppercase text-left" style="color: #576574;font-family: 'Bitter', serif;"><?php echo $blog3['judul_blog'];?></p>
          <hr width="100%">
          <p class="text-left" style="color: #576574;font-family: 'Bitter', serif;text-align: left;"><?php echo substr($blog3['konten'],0,50)?>...</p>
        </a>
    </form>
  </span>
  <?php  endforeach;?>
      </div>
    
    </div>

<!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#blog" data-slide-to="0" class="active" style="border: #8395a7 1px solid;"></li>
      <li data-target="#blog" data-slide-to="1" style="border: #8395a7 1px solid;"></li>
      <li data-target="#blog" data-slide-to="2" style="border: #8395a7 1px solid;"></li>
    </ol>
  </div>
  <br>
        </div>
      </div>
    </div>
<div id='kontes'>
<div class='float'>
  <a href="https://api.whatsapp.com/send?phone=6281322220417&text=Hallo%20RonysDesign.com"><button class="btn-wa"><i class="fa fa-whatsapp"></i></button></a>
</div></div>
  <!-- FOOTER -->
  <footer id="footer" class="section" style="font-family: 'Oswald', sans-serif;background: #222f3e;color: #fff;">
    <!-- container -->
      <div class="container">
        <div class="row">
        <!-- footer widget -->
        <center>
        <h4 class="text-uppercase">follow kami</h4>
        <h4 class="text-center">Klik icon dibawah ini</h4>
        <h4 class="text-center">untuk mengunjungi media sosial kami</h4>
        <a href="" style="text-decoration: none; color: #fff; padding-right: 10px;"><i class="fa fa-twitter"></i></a>
        <a href="https://web.facebook.com/ronysdesign.media" style="text-decoration: none; color: #fff; padding-right: 10px;"><i class="fa fa-facebook"></i></a>
        <a href="https://www.instagram.com/ronysdesign/" style="text-decoration: none; color: #fff; padding-right: 10px;"><i class="fa fa-instagram"></i></a>
        <a href="mailto:ronysdesign@gmail.com" style="text-decoration: none; color: #fff; padding-right: 10px;"><i class="fa fa-google"></i></a>
      </center>
      </div>
    </div>
      <!-- /row -->
    <!-- /container -->
  </footer>
  <!-- /FOOTER -->

  <script type="text/javascript">
    
  </script>

  <script src="<?php echo base_url()?>assets/js/jquery-3.3.1.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url()?>assets/js/jquery-ui.js" type="text/javascript"></script>
  <script src="<?php echo base_url()?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/bootstrap.min.js?<?php echo time();?>"></script>
  <script src="<?php echo base_url()?>assets/js/owl.carousel.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url()?>assets/js/aos.js"></script>
  <script src="<?php echo base_url()?>assets/js/slick.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url()?>assets/js/nouislider.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/main.js?<?php echo time();?>"></script>
    
  </body>
</html>