<link href="<?php echo base_url('assets');?>/ace/assets/css/bootstrap.min.css" rel="stylesheet" />
		<link href="<?php echo base_url('assets');?>/ace/assets/css/bootstrap-responsive.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/font-awesome.min.css" />
		<script src="<?php echo base_url('assets');?>/Js/jquery.min.js"></script>
		<script  type="text/javascript" src="<?php echo base_url('assets');?>/ckeditor/ckeditor.js"></script>

		<!--[if IE 7]>
		  <link rel="stylesheet" href="ace/assets/css/font-awesome-ie7.min.css" />
		<![endif]-->

		<!--page specific plugin styles-->

		<!--fonts-->

		<!-- <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" /> -->

		<!--ace styles-->

		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace.min.css" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace-responsive.min.css" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace-skins.min.css" />
		
<form action="<?php echo site_url('admin/ubahproduk'); ?>" method="post"  enctype="multipart/form-data">
	<?php foreach ($product as $product)?>
					<div class="form-group">
						<label>Nama Produk</label>
						<input name="id_produk" type="hidden" value="<?php echo $product['id_product'] ?>">
						<input name="nama_produk" type="text" class="form-control" placeholder="Nama Produk .." value="<?php echo $product['product_name'] ?>"  required="required">
					</div>
					<div class="form-group">
						<label>Kategori Produk</label>
						<select name="kategory" class="form-control"  required="required">
							<?php foreach ($kategory2 as $kategory2):?>
								<option value="<?php echo $kategory2['id_kategory'];?>"><?php echo $kategory2['nama_kategory'];?></option>
							<?php foreach ($kategory as $kategory):?>
								<option value="<?php echo $kategory['id_kategory'];?>"><?php echo $kategory['nama_kategory'];?></option>
							<?php endforeach;?>
						</select>
					</div>
					<div class="form-group">
						<label>Deskripsi Produk</label>
						<textarea name="deskripsi" type="text" class="form-control" placeholder="Deskripsi .." value="<?php echo $product['description'] ?>"  required="required" id="ckeditor1"><?php echo $product['description'] ?></textarea>
					</div>

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
					<input type="submit" class="btn btn-primary" value="Simpan">
				</div>
			<?php endforeach;?>
			</form>
			<script>
	ClassicEditor
		.create( document.querySelector( '#ckeditor1' ), {
			// toolbar: [ 'heading', '|', 'bold', 'italic', 'link' ]
		} )
		.then( editor => {
			window.editor = editor;
		} )
		.catch( err => {
			console.error( err.stack );
		} );
</script>