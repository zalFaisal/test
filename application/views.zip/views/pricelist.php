<?php  ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Rony Design - Pricelist</title>
    <link rel="icon" href="<?php echo base_url()?>assets/images/icon.jpg">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Mukta:300,400,700"> 
    <link rel="stylesheet" href="<?php echo base_url()?>assets/fonts/icomoon/style.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/w3.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/jquery-ui.css">
  <link type="text/css" rel="stylesheet" href="<?php echo base_url()?>assets/css/slick.css" />
  <link type="text/css" rel="stylesheet" href="<?php echo base_url()?>assets/css/slick-theme.css" />
  <link href="https://fonts.googleapis.com/css?family=Bitter|Kreon|Mukta|Oswald|Roboto+Condensed" rel="stylesheet"> 
  <link type="text/css" rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css?<?php echo time();?>">
  <!-- nouislider -->
  <!-- Font Awesome Icon -->
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/font-awesome.min.css">
   
  
  </head>
  <style type="text/css">
  @media only screen and (max-width: 740px){
    .col-deskripsi{
  width: 90%;
  height: auto;
  position: relative;
  padding-left: 15px;
  }
    .tabel{
      width: 96%;
      height: auto;
    }
    .kolom{
      background-color: #fed330;
      color: #2d3436;
      font-size: 10px;
      font-family: 'Oswald', sans-serif;
    }
    .baris{
      background-color: #fff;
      color: #222f3e;
      font-size: 10px;
      font-family: 'Oswald', sans-serif;
    }
    .span-hubungi{
  height: 130px;
  width: 90%;
}
.span-hubungi p{
  padding-bottom: 7px;
}
.label-hubungi{
  width: 90%;
  height: 40px;
  background: transparent;
  border: #fff 1px solid;
  line-height: 40px;
  float: left;
  font-size: 11px;
  text-align: left;
  padding-left: 15px;
}
   .col-deskripsi{
  width: 90%;
  height: auto;
  position: relative;
  padding-left: 15px;
  }
  .head-des{
    padding-left: 15px;
  }
  .foto-banner{
    width: 100%;
    height: 180px;
  }
  }
  @media only screen and (min-width: 768px){
    .col-deskripsi{
  width: 55%;
  height: auto;
  position: relative;
  padding-left: 0px;
}
    .tabel{
      width: 74%;
      height: auto;
    }
    .kolom{
      background-color: #fed330;
      color: #636e72;
      font-size: 14px;
      font-family: 'Bitter', serif;
    }
    .baris{
      background-color: #fff;
      color: #636e72;
      font-size: 14px;
      font-family: 'Bitter', serif;
    }
    .span-hubungi{
  height: 300px;
  width: 74%;
  
}
.span-hubungi p{
  padding-bottom: 40px;
}
.label-hubungi{
  width: 65%;
  height: 60px;
  background: transparent;
  border: #fff 1px solid;
  line-height: 50px;
  float: left;
  font-size: 22px;
  text-align: left;
  padding-left: 15px;
}

.head-des{
    padding-left: 149px;
  }
  .foto-banner{
    width: 100%;
    height: 500px;
  }
  }
  .foto{
    width: 50px;
    height: 180px;
  }
  .jarak-kiri{
    padding-left: 10px;
  }
.card-testimoni{
  position: fixed;

  height: auto;
  width: 260px;
  background: #fff;
  border: #d1d8e0 1px solid;
  color: #f7b731;
  padding: 10px;
  border-radius: 2px;
  margin-right: auto;
  margin-left: auto;
  text-align: center;
  transition: all 0.3s ease 0s;
  font-size: 14px;
  display: inline-block;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -ms-box-sizing: border-box;
  -o-box-sizing: border-box;
}
.card-testimoni:hover{
  box-shadow: 0px 10px 15px rgba(0, 0, 0, 0.1);
}
  </style>
  <body>
  
  <div class="site-wrap">
     <header class="site-navbar" role="banner">
      <div id="top-header" style="background: #cccccc;">
      <div class="container">
        <div class="pull-right">
            <a href="https://api.whatsapp.com/send?phone=6281322220417&text=Hallo%20RonysDesign.com" target="_blank" style="color: #636e72;font-family: 'Roboto Condensed', sans-serif;"><i class="fa fa-whatsapp"></i><span> 081322220417 | </span></a>
            <a href="mailto:ronysdesign@gmail.com" style="color: #636e72;font-family: 'Roboto Condensed', sans-serif;"><i class="fa fa-envelope"></i>  <span>ronysdesign@gmail.com</span></a>
        </div>
      </div>
    </div>
      <div class="site-navbar-top">
        <div class="container">
          <div class="row align-items-center">

            <div class="col-6 mb-3 mb-md-0 col-md-4 order-1 order-md-2 text-left logo-position">
              <div class="site-logo">
               <img src="<?php echo base_url().'assets/images/riffData.png'?>" class="logo" onclick="location.href='<?php echo site_url('')?>'">
              </div>
            </div>

            <div class="col-6 col-md-4 order-2 order-md-1 site-search-icon text-right logo-position-sc">
              <div class="header-search">
            <form action="<?php echo site_url('search');?>" method="get">
              <input class="input search-input" name="q" type="text" placeholder="Cari Produk">
              <button class="search-btn"><i class="fa fa-search" style="color: #fff;"></i></button>
            </form>
          </div>
            </div>

            
            <div id="header">
            <div class="col-12 mb-3 mb-md-0 col-md-4 order-1 order-md-2 text-left">
              <br><br>
             <span class="nav-toggle">
              <button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
            </span>
            </div>
            </div>
          </div>
        </div>
      </div> 
      <div id="navigation">
    <!-- container -->
    <div class="container">
      <div id="responsive-nav">

        <!-- menu nav -->
        <div class="menu-nav">
          <span class="menu-header">Menu <i class="fa fa-bars"></i></span>
          <ul class="menu-list">
            <?php foreach ($kategory as $kategory):
              $this->load->model('Transaksi');
              $id_kat = $kategory['id_kategory'];
              $produk = $this->Transaksi->getProduk($id_kat);
              ?>
            <li class="dropdown mega-dropdown full-width"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" style="cursor: default;"><?php echo $kategory['nama_kategory'] ?><i class="fa fa-caret-down jarak-kiri"></i></a>
              <div class="custom-menu">
                <div class="row">
                  <?php foreach ($produk as $produk):?>
                  <div class="col-md-2">
                    <div class="hidden-sm hidden-xs">
                      <a href="<?php echo site_url('product/'.$produk['slug_name']);?>">
                        <img style="width: 170px;height: 170px;" src="<?php echo base_url().'uploads/'.$produk['product_photo']?>" alt=""></a>
                    </div>
                    <a href="<?php echo site_url('product/'.$produk['slug_name']);?>">
                    <div class="text-left">
                       <h5 class="text-uppercase"><p><?php echo $produk['product_name'];?></p></h5>
                    </div>
                  </a>
                  </div>
                <?php endforeach;?>
                </div>
              </div>
            </li>
          <?php endforeach;?>
            <li><a href="<?php echo site_url('blog');?>" style="cursor: default;">BLOG</a></li>
          </ul>
        </div>
        <!-- menu nav -->
      </div>
    </div>
    <!-- /container -->
  </div>
    </header>
    <?php foreach ($banner as $banner):?>
            <center>
            <img src="<?php echo base_url().'uploads/'.$banner['banner_photo']?>" class="foto-banner">
          </center>
          <?php endforeach;?>
    <div class="site-section site-section-sm site-blocks-1">
      <div class="container">
        <div class="row">

        	
          <br>
          <div class="head-des">
            <?php foreach($judul as $judul):?>
            <h3 style="font-family: 'Oswald', sans-serif;"><?= $judul['product_name']?></h3>
            <hr width="85%" align="center">
            <h4 style="font-family: 'Oswald', sans-serif;">Keterangan :</h4><br>
            <div class="col-deskripsi">
              <?= $judul['description']?>
            </div>
          <?php endforeach;?>
          <br>
          <a href="<?php echo site_url('detail/'.$this->uri->segment(3));?>"><button class="btn-detail">Detail Produk</button></a>
        </div>
        </div>
    </div>
  </div>
<div class="site-section site-section-sm site-blocks-1">
      <div class="container">
        <div class="row">
          <h3 class="text-center sub-judul"  style="font-family: 'Oswald', sans-serif;">PRICELIST PRODUK</h3>
          <center>
          <hr class="garis" align="center"><br><br>
          <table class="table table-hover tabel">
    <thead>
      <tr class="kolom">
        <th>No.</th>
        <th>Quantity</th>
        <th>Satuan</th>
        <th>Nama Bahan</th>
        <th>Harga Satuan</th>
        <th>Sub Total</th>
      </tr>
    </thead>
    <tbody>
      <?php $no=1; foreach($pricelist as $pricelist):?>
      <tr class="baris">
        <td><?= $no;?></td>
        <td><?= '@'.$pricelist['quantity']?></td>
        <td><?= $pricelist['satuan']?></td>
        <td><?= $pricelist['nama_bahan']?></td>
        <td><?= 'Rp ' . number_format($pricelist['harga_per_pcs'], '2', ',', '.');?></td>
        <td><?= 'Rp ' . number_format($pricelist['harga_per_pcs']*$pricelist['quantity'], '2', ',', '.');?></td>
      </tr>
    <?php $no+=1; endforeach;?>
    </tbody>
  </table>
        </center>
          
        </div>
      </div>
    </div>
    <div class="site-section site-section-sm site-blocks-1">
      <div class="container">
        <div class="row">
          <center>
          <h3 class="text-center sub-judul"  style="font-family: 'Oswald', sans-serif;text-align: center;">PRODUK PERCETAKAN</h3></center><br>
          <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      
      <div class="item active">
        <?php foreach ($produklim as $produklim): ?>
           <!-- Product Single -->
            <span class="span-card">
              <center>
    <form class="card-produk">
      <img style="width: 240px;height: 180px;" src="<?php echo base_url().'uploads/'.$produklim['product_photo']?>" alt="">
        <br><br>
          <a href="<?php echo site_url('product/'.$produklim['slug_name']);?>">
          <p class="text-uppercase text-left" style="color: #576574;font-family: 'Bitter', serif;"><?php echo $produklim['product_name'];?></p>
          <hr width="100%">
          <p class="text-left"><i  style="color: #576574;font-family: 'Bitter', serif;"><?php echo substr($produklim['description'],0,40)?></i></p>
        </a>
    </form>
  </center>
  </span>
          <?php endforeach;?>
          <center>
          <div style="padding-top: 50px;"><center><a href="<?php echo site_url('allproduct');?>"><button class="btn-all-produk">LIHAT SEMUA PRODUK</button></a></center></div></center>
      </div>
    </div>


  </div>
          <div class="isi">
          
        </div>
        </div>
      </div>
    </div>
<div id='kontes'>
<div class='float'>
  <a href="https://api.whatsapp.com/send?phone=6281322220417&text=Hallo%20RonysDesign.com"><button class="btn-wa"><i class="fa fa-whatsapp"></i></button></a>
</div></div>


  <!-- FOOTER -->
    <footer id="footer" class="section" style="font-family: 'Oswald', sans-serif;background: #222f3e;color: #fff;">
    <!-- container -->
      <div class="container">
        <div class="row">
        <!-- footer widget -->
        <center>
        <h4 class="text-uppercase">follow kami</h4>
        <h4 class="text-center">Klik icon dibawah ini</h4>
        <h4 class="text-center">untuk mengunjungi media sosial kami</h4>
        <a href="" style="text-decoration: none; color: #fff; padding-right: 10px;"><i class="fa fa-twitter"></i></a>
        <a href="https://web.facebook.com/ronysdesign.media" style="text-decoration: none; color: #fff; padding-right: 10px;"><i class="fa fa-facebook"></i></a>
        <a href="https://www.instagram.com/ronysdesign/" style="text-decoration: none; color: #fff; padding-right: 10px;"><i class="fa fa-instagram"></i></a>
        <a href="mailto:ronysdesign@gmail.com" style="text-decoration: none; color: #fff; padding-right: 10px;"><i class="fa fa-google"></i></a>
      </center>
      </div>
    </div>
      <!-- /row -->
    <!-- /container -->
  </footer>
  <!-- /FOOTER -->


<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Harga Produk</h4>
      </div>
      <div class="modal-body">
        <table class="table table-hover">
    <thead>
      <tr>
        <th>No.</th>
        <th>Quantity</th>
        <th>Nama Bahan</th>
        <th>Harga Satuan</th>
        <th>Sub Total</th>
      </tr>
    </thead>
    <tbody>
      <?php $no=1; foreach($pricelist as $pricelist):?>
      <tr>
        <td><?= $no;?></td>
        <td><?= '@'.$pricelist['quantity']?></td>
        <td><?= $pricelist['nama_bahan']?></td>
        <td><?= 'Rp ' . number_format($pricelist['harga_per_pcs'], '2', ',', '.');?></td>
        <td><?= 'Rp ' . number_format($pricelist['harga_per_pcs']*$pricelist['quantity'], '2', ',', '.');?></td>
      </tr>
    <?php $no+=1; endforeach;?>
    </tbody>
  </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
  <script type="text/javascript">
    (function ($) {
  "use strict";
  // Auto-scroll
  $('#myCarousel').carousel({
    interval: 5000
  });

  // Control buttons
  $('.next').click(function () {
    $('.carousel').carousel('next');
    return false;
  });
  $('.prev').click(function () {
    $('.carousel').carousel('prev');
    return false;
  });

  // On carousel scroll
  $("#myCarousel").on("slide.bs.carousel", function (e) {
    var $e = $(e.relatedTarget);
    var idx = $e.index();
    var itemsPerSlide = 3;
    var totalItems = $(".carousel-item").length;
    if (idx >= totalItems - (itemsPerSlide - 1)) {
      var it = itemsPerSlide -
          (totalItems - idx);
      for (var i = 0; i < it; i++) {
        // append slides to end 
        if (e.direction == "left") {
          $(
            ".carousel-item").eq(i).appendTo(".carousel-inner");
        } else {
          $(".carousel-item").eq(0).appendTo(".carousel-inner");
        }
      }
    }
  });
})
(jQuery);
  </script>
  <script src="<?php echo base_url()?>assets/js/jquery-3.3.1.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url()?>assets/js/jquery-ui.js" type="text/javascript"></script>
  <script src="<?php echo base_url()?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/bootstrap.min.js?<?php echo time();?>"></script>
  <script src="<?php echo base_url()?>assets/js/owl.carousel.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url()?>assets/js/aos.js"></script>
  <script src="<?php echo base_url()?>assets/js/slick.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url()?>assets/js/nouislider.min.js"></script>
  <script src="<?php echo base_url()?>assets/js/main.js?<?php echo time();?>"></script>
    
  </body>
</html>