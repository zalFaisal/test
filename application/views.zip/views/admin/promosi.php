<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<title>Administrator</title>

		<meta name="description" content="Static &amp; Dynamic Tables" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />

		<!--basic styles-->

		<link href="<?php echo base_url('assets');?>/ace/assets/css/bootstrap.min.css" rel="stylesheet" />
		<link href="<?php echo base_url('assets');?>/ace/assets/css/bootstrap-responsive.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/font-awesome.min.css" />
		<script src="<?php echo base_url('assets');?>/js/jquery.min.js"></script>
		<script  type="text/javascript" src="<?php echo base_url('assets');?>/ckeditor/ckeditor.js"></script>

		<!--[if IE 7]>
		  <link rel="stylesheet" href="ace/assets/css/font-awesome-ie7.min.css" />
		<![endif]-->

		<!--page specific plugin styles-->

		<!--fonts-->

		<!-- <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" /> -->

		<!--ace styles-->

		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace.min.css" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace-responsive.min.css" />
		<link rel="stylesheet" href="<?php echo base_url('assets');?>/ace/assets/css/ace-skins.min.css" />
		

		<!--[if lte IE 8]>
		  <link rel="stylesheet" href="ace/assets/css/ace-ie.min.css" />
		<![endif]-->

		<!--inline styles related to this page-->
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
	<style type="text/css">
		.imgsize{
			width: 55px;
			height: 55px;
		}
	</style>
	<body>
	
		<div class="navbar">
			<div class="navbar-inner">
				<div class="container-fluid">
					<a href="<?php echo site_url('admin'); ?>" class="brand">
						<small>
							<i class="icon-leaf"></i>
							Administrator
						</small>
					</a><!--/.brand-->

					<ul class="nav ace-nav pull-right">
						<li class="green">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="icon-envelope icon-animated-vertical"></i>
								<span class="badge badge-success" id="jumlah1"></span>
							</a>

							<ul class="pull-right dropdown-navbar dropdown-menu dropdown-caret dropdown-closer" id="load-pesan">

							</ul>
						</li>

						<li class="light-blue">
							<a data-toggle="dropdown" href="#" class="dropdown-toggle">
								<img class="nav-user-photo" src="<?php echo base_url('assets');?>/ace/assets/avatars/user.jpg" alt="Jason's Photo" />
								<span class="user-info">
									<small>Welcome,</small>
									<?php echo $this->session->userdata("NAME"); ?>
								</span>

								<i class="icon-caret-down"></i>
							</a>

							<ul class="user-menu pull-right dropdown-menu dropdown-yellow dropdown-caret dropdown-closer">
								<li>
									<a href="#">
										<i class="icon-cog"></i>
										Settings
									</a>
								</li>

								<li>
									<a href="#">
										<i class="icon-user"></i>
										Profile
									</a>
								</li>

								<li class="divider"></li>

								<li>
									<a href="<?php echo site_url('login/logout'); ?>">
										<i class="icon-off"></i>
										Logout
									</a>
								</li>
							</ul>
						</li>
					</ul><!--/.ace-nav-->
				</div><!--/.container-fluid-->
			</div><!--/.navbar-inner-->
		</div>

		<div class="main-container container-fluid">
			<a class="menu-toggler" id="menu-toggler" href="#">
				<span class="menu-text"></span>
			</a>

			<div class="sidebar" id="sidebar">
				<div class="sidebar-shortcuts" id="sidebar-shortcuts">
					<div class="sidebar-shortcuts-large" id="sidebar-shortcuts-large">
						<button class="btn btn-small btn-success">
							<i class="icon-signal"></i>
						</button>

						<button class="btn btn-small btn-info">
							<i class="icon-pencil"></i>
						</button>

						<button class="btn btn-small btn-warning">
							<i class="icon-group"></i>
						</button>

						<button class="btn btn-small btn-danger">
							<i class="icon-cogs"></i>
						</button>
					</div>

					<div class="sidebar-shortcuts-mini" id="sidebar-shortcuts-mini">
						<span class="btn btn-success"></span>

						<span class="btn btn-info"></span>

						<span class="btn btn-warning"></span>

						<span class="btn btn-danger"></span>
					</div>
				</div><!--#sidebar-shortcuts-->

				
				<ul class="nav nav-list">
					<li>
						<a href="<?php echo site_url('admin');?>">
							<i class="icon-dashboard"></i>
							<span class="menu-text"> Produk </span>
						</a>
					</li>
					<li>
						<a href="<?php echo site_url('Admin/foto_produk');?>">
							<i class="icon-dashboard"></i>
							<span class="menu-text"> Foto Produk </span>
						</a>
					</li>
					<li>
						<a href="<?php echo site_url('Admin/promotion');?>">
							<i class="icon-inbox"></i>
							<span class="menu-text"> Promosi</span>
						</a>
					</li>
					<li>
						<a href="<?php echo site_url('admin/pricelist');?>">
							<i class="icon-credit-card"></i>
							<span class="menu-text"> Data Pricelist </span>
						</a>
					</li>
					<li>
						<a href="<?php echo site_url('admin/kategori');?>">
							<i class="icon-list-ul"></i>
							<span class="menu-text"> Data Kategory </span>
						</a>
					</li>
					<li>
						<a href="<?php echo site_url('admin/material');?>">
							<i class="icon-cogs"></i>
							<span class="menu-text"> Bahan </span>
						</a>
					</li>
					<li>
						<a href="<?php echo site_url('Admin/pelanggan');?>">
							<i class="icon-bar-chart"></i>
							<span class="menu-text"> Pelanggan </span>
						</a>
					</li>
					<li>
						<a href="<?php echo site_url('Admin/blog');?>">
							<i class="icon-pencil"></i>
							<span class="menu-text"> Blog </span>
						</a>
						<li>
						<a href="<?php echo site_url('Admin/testimoni');?>">
							<i class="icon-group"></i>
							<span class="menu-text"> Testimoni </span>
						</a>
					</li>
					<li>
						<a href="<?php echo site_url('Admin/video');?>">
							<i class="icon-signal"></i>
							<span class="menu-text"> Video </span>
						</a>
					</li>
					<li>
						<a href="<?php echo site_url('Admin/cetak_promosi');?>">
							<i class="icon-inbox"></i>
							<span class="menu-text"> Promosi Cetak Kustom</span>
						</a>
					</li>
					</li>
				</ul><!--/.nav-list-->

				<div class="sidebar-collapse" id="sidebar-collapse">
					<i class="icon-double-angle-left"></i>
				</div>
			</div>

			<div class="main-content">
				<div class="page-content">
				<div class="row-fluid">
					<div class="page-header position-relative">
						<h1>
							<?php echo $title?>
							<small>
								<i class="icon-double-angle-right"></i>
								<?php echo $sub_title?>
							</small>
						</h1>
					</div><!--/.page-header-->


	<div class="row-fluid">
		<button style="margin-bottom:20px" data-toggle="modal" data-target="#myModal" class="btn btn-info col-md-2"><span class="glyphicon glyphicon-plus"></span>Tambah Promosi</button>
	</div>
	<form action="<?php echo site_url('Admin/promotionsearch'); ?>" method="get">
	<div class="input-group col-md-5 col-md-offset-7">
		<span class="input-group-addon" id="basic-addon1"><span class="glyphicon glyphicon-search"></span></span>
		<input type="text" class="form-control" placeholder="Cari Bahan .." aria-describedby="basic-addon1" name="cari">
	</div>
</form>
<table class="table table-hover">
	<tr>
		<th class="col-md-1">No</th>
		<th class="col-md-1">ID Promosi</th>
		<th class="col-md-4">Title</th>
		<th class="col-md-4">Konten</th>
		<th class="col-md-3">Foto Bahan</th>
		<!-- <th class="col-md-1">Sisa</th>		 -->
		<th class="col-md-3">Opsi</th>
	</tr>
	<?php
	 $no = 1;
	 foreach ($product as $product):?>
		<tr>
			<td><?php echo $no ?></td>
			<td><?php echo $product['id_promosi'] ?></td>
			<td><?php echo $product['judul_promosi'] ?></td>
			<td><?php echo substr($product['konten'],0,20).'...' ?></td>
			<td><img src="<?php echo base_url().'uploads/'.$product['foto_banner_promosi'] ?>" class="img-fluid imgsize"></td>
			<td>
				<div class="btn-group btn-group-justified">
				<a href="<?php echo site_url('Admin/editPromosi/'.$product['id_promosi']); ?>" class="btn btn-success" data-toggle="modal" data-target="#editModal" target="detail_prod">Edit</a>
				<a onclick="if(confirm('Apakah anda yakin ingin menghapus data ini ??')){ location.href='<?php echo site_url('Admin/hapusPromosi/'.$product['id_promosi'])?>' }" class="btn btn-danger">Hapus</a>
				</div>
			</td>
		</tr>
		<?php
		$no+=1;
	endforeach;
	?>
</table>
</div>
				</div>


				<!-- modal input -->
<div id="myModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Tambah Data Baru</h4>
			</div>
			<div class="modal-body">
				<form action="<?php echo site_url('Admin/addPromosi'); ?>" method="post"  enctype="multipart/form-data">
					
					<input type="hidden" name="id_produk" value="<?= $autokode; ?>">
				
					<div class="form-group">
						<label>Judul Promosi</label>
						<input name="nama_produk" type="text" class="form-control" placeholder="Nama Produk .."  required="required">
					</div>
					<div class="form-group">
						<label>Konten</label>
						<textarea name="deskripsi" class="ckeditor" id="ckeditor" placeholder="Deskripsi .."></textarea>
					</div>
					<div class="form-group">
						<label>Banner Promosi</label>
						<input name="foto_thumbnail" type="file" placeholder="Foto Thumbnail .."  required="required">
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
					<input type="submit" class="btn btn-primary" value="Simpan">
				</div>
			</form>
		</div>
	</div>
</div>

<!-- modal buat nampilin form edit-->
<div id="editModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" onclick="location.href='<?php echo site_url('Admin/promotion')?>'">&times;</button>
				<h4 class="modal-title">Edit Promosi</h4>
			</div>
			<div class="modal-body">
				<iframe width="96%" height="100%"  frameborder="0" name="detail_prod"></iframe>
		</div>
	</div>
</div>
</div>
	<!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script> -->

		<!--<![endif]-->

		<!--[if IE]>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<![endif]-->

		<!--[if !IE]>-->
<script>
	ClassicEditor
		.create( document.querySelector( '#ckeditor' ), {
			// toolbar: [ 'heading', '|', 'bold', 'italic', 'link' ]
		} )
		.then( editor => {
			window.editor = editor;
		} )
		.catch( err => {
			console.error( err.stack );
		} );
</script>
<script>
	ClassicEditor
		.create( document.querySelector( '#ckeditor1' ), {
			// toolbar: [ 'heading', '|', 'bold', 'italic', 'link' ]
		} )
		.then( editor => {
			window.editor = editor;
		} )
		.catch( err => {
			console.error( err.stack );
		} );
</script>
		<script type="text/javascript">
			window.jQuery || document.write("<script src='<?php echo base_url('assets');?>/ace/assets/js/jquery-2.0.3.min.js'>"+"<"+"/script>");
		</script>

		<!--<![endif]-->

		<!--[if IE]>
<script type="text/javascript">
 window.jQuery || document.write("<script src='assets/js/jquery-1.10.2.min.js'>"+"<"+"/script>");
</script>
<![endif]-->

		<script type="text/javascript">
			if("ontouchend" in document) document.write("<script src='<?php echo base_url('assets');?>/ace/assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
		</script>
		<script src="<?php echo base_url('assets');?>/ace/assets/js/bootstrap.min.js"></script>

		<!--page specific plugin scripts-->

		<!--[if lte IE 8]>
		  <script src="assets/js/excanvas.min.js"></script>
		<![endif]-->
		
		<script src="<?php echo base_url('assets');?>/ace/assets/js/jquery-ui-1.10.3.custom.min.js"></script>
		<script src="<?php echo base_url('assets');?>/ace/assets/js/jquery.ui.touch-punch.min.js"></script>


		<!--ace scripts-->

		<script src="<?php echo base_url('assets');?>/ace/assets/js/ace-elements.min.js"></script>
		<script src="<?php echo base_url('assets');?>/ace/assets/js/ace.min.js"></script>

		<!--inline scripts related to this page-->

	</body>
	
		</html>
